-- DADOSLAB - Diagnóstico resumido - 19/10/2026
-- Nome:
-- Turma:
-- SGBD da turma: a confirmar. Não é necessário executar.

-- Pergunta 4: listar somente os títulos com quantidade >= 2.
-- Consulte a tabela livros em 01-base-referencia.html.

-- Minha tentativa SQL ou explicação:



-- Registre esta tentativa na ficha e entregue um único TXT ao professor.
