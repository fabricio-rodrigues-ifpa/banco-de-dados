-- DADOSLAB - Diagnóstico MySQL - 19/10/2026
-- Nome:
-- Turma:
-- Ajuste o USE se o professor indicar outro esquema de estudo.
USE dadoslab_diagnostico_2026;

-- P1 - Consulta escrita por você
-- Escreva uma consulta que mostre id, titulo e quantidade dos livros com pelo
-- menos dois exemplares, em ordem de quantidade decrescente e id crescente.
-- Preveja o resultado antes de executar.



-- P2 - Relatório com zero
-- Escreva uma consulta que mostre cada leitor e a quantidade de seus
-- empréstimos ainda sem devolução. Inclua quem tem zero e ordene por id do
-- leitor. Explique onde colocou o teste de NULL.



-- P3 - Alteração com conferência
-- No esquema fictício, escreva uma transação que registre a devolução do
-- empréstimo 103 em 19/10/2026. Confira somente esse registro antes e depois.
-- Desfaça o teste com ROLLBACK e confira novamente. Não inclua CREATE ou DROP
-- nessa transação.



-- Registre previsão, resultado e apoio na ficha.
-- Entregue o SQL e os TXT inicial e final ao professor.
