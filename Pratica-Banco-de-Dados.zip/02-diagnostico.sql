-- DADOSLAB - Diagnóstico de Banco de Dados - 19/10/2026
-- Nome:
-- Turma:
-- SGBD a confirmar. Somente leitura, previsão e escrita nesta atividade.
-- Consulte 01-base-referencia.html. Não é necessário executar SQL.

-- P1 - Filtro com resultado previsto
-- Escreva uma consulta que mostre id, titulo e quantidade dos livros com pelo
-- menos dois exemplares. Ordene por quantidade decrescente e, nos empates, por
-- id crescente. Antes de consultar qualquer material, registre os IDs na ordem
-- esperada.

-- Minha tentativa:



-- Resultado previsto e justificativa:


-- Apoio recebido:


-- P2 - Relatório com zeros
-- Escreva uma consulta com nome e total de empréstimos sem devolução
-- registrada por leitor, incluindo leitores com zero. Ordene pelo id do
-- leitor. Preveja os quatro totais e explique onde colocou a condição de
-- devolução.

-- Minha tentativa:



-- Resultado previsto e justificativa:


-- Apoio recebido:


-- P3 - Alteração descrita em SQL
-- Somente no papel ou no arquivo SQL, escreva o comando para mudar a turma de
-- Duda (id 4) de 1B para 1C. Indique a linha antes e depois e explique como
-- restringiu a alteração. Considere a base inicial e não execute esse comando
-- nesta atividade.

-- Minha tentativa:



-- Resultado previsto e justificativa:


-- Apoio recebido:


-- Salve com nome e turma no conteúdo e no nome do arquivo.
-- Entregue este SQL e os TXT inicial e final ao professor na aula.
