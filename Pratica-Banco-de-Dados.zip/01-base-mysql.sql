-- MySQL 8.0/8.4, tabelas InnoDB. Dados fictícios.
-- Execute uma vez em um esquema de estudo vazio.
-- Se não houver permissão para CREATE DATABASE, solicite ao professor
-- o esquema individual e ajuste apenas o CREATE DATABASE/USE abaixo.
CREATE DATABASE IF NOT EXISTS dadoslab_diagnostico_2026
  CHARACTER SET utf8mb4;
USE dadoslab_diagnostico_2026;

CREATE TABLE livros (
  id INT NOT NULL PRIMARY KEY,
  titulo VARCHAR(120) NOT NULL,
  area VARCHAR(40) NOT NULL,
  quantidade INT UNSIGNED NOT NULL
) ENGINE = InnoDB;

CREATE TABLE leitores (
  id INT NOT NULL PRIMARY KEY,
  nome VARCHAR(80) NOT NULL,
  turma VARCHAR(20) NOT NULL
) ENGINE = InnoDB;

CREATE TABLE emprestimos (
  id INT NOT NULL PRIMARY KEY,
  livro_id INT NOT NULL,
  leitor_id INT NOT NULL,
  data_emprestimo DATE NOT NULL,
  data_devolucao DATE NULL,
  CONSTRAINT fk_emprestimo_livro
    FOREIGN KEY (livro_id) REFERENCES livros (id),
  CONSTRAINT fk_emprestimo_leitor
    FOREIGN KEY (leitor_id) REFERENCES leitores (id)
) ENGINE = InnoDB;

INSERT INTO livros (id, titulo, area, quantidade) VALUES
  (1, 'Redes de Computadores', 'Redes', 2),
  (2, 'Banco de Dados', 'Dados', 1),
  (3, 'HTML e CSS', 'Web', 3),
  (4, 'Lógica de Programação', 'Programação', 2),
  (5, 'Linux em Redes', 'Redes', 1);

INSERT INTO leitores (id, nome, turma) VALUES
  (1, 'Ana', '1A'),
  (2, 'Bruno', '1A'),
  (3, 'Caio', '1B'),
  (4, 'Duda', '1B');

INSERT INTO emprestimos
  (id, livro_id, leitor_id, data_emprestimo, data_devolucao)
VALUES
  (101, 1, 1, '2026-10-10', NULL),
  (102, 3, 2, '2026-10-11', '2026-10-15'),
  (103, 1, 3, '2026-10-12', NULL),
  (104, 2, 1, '2026-10-13', '2026-10-16'),
  (105, 3, 1, '2026-10-17', NULL);
