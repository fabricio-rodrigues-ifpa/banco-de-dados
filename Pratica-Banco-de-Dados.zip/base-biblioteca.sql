-- DADOSLAB - Base SQLite da primeira aula
-- Execute uma vez em um banco de estudo vazio. Não contém DROP.
-- Todos os dados são fictícios.

PRAGMA foreign_keys = ON;
CREATE TABLE livros (
  id INTEGER PRIMARY KEY,
  titulo TEXT NOT NULL,
  area TEXT NOT NULL,
  quantidade INTEGER NOT NULL CHECK (quantidade >= 0)
);
CREATE TABLE emprestimos (
  id INTEGER PRIMARY KEY,
  livro_id INTEGER NOT NULL REFERENCES livros(id),
  leitor TEXT NOT NULL,
  data_emprestimo TEXT NOT NULL,
  data_devolucao TEXT
);
INSERT INTO livros (id, titulo, area, quantidade) VALUES
  (1, 'Redes de Computadores', 'Redes', 2),
  (2, 'Banco de Dados', 'Dados', 1),
  (3, 'HTML e CSS', 'Web', 3),
  (4, 'Lógica de Programação', 'Programação', 2);
INSERT INTO emprestimos
  (id, livro_id, leitor, data_emprestimo, data_devolucao) VALUES
  (101, 1, 'Ana', '2026-10-10', NULL),
  (102, 3, 'Bruno', '2026-10-11', '2026-10-15'),
  (103, 1, 'Caio', '2026-10-12', NULL);
