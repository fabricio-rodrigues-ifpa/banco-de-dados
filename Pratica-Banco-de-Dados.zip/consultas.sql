-- DADOSLAB - Diagnóstico de Banco de Dados - 19/10/2026
-- Nome:
-- Turma:
-- Primeiro registre sua previsão. Depois execute e confira.

-- 1. Consulta inicial:
SELECT *
FROM livros;

-- 2. Investigue a consulta abaixo. Compare a coluna com os campos da base.
SELECT titulo
FROM livros
WHERE categoria = 'Redes';

-- 3. Escreva sua consulta: titulo e quantidade dos livros
--    com pelo menos dois exemplares cadastrados.


-- 4. Desafio opcional: combinar livros e emprestimos para mostrar
--    titulo e leitor dos emprestimos ainda sem devolucao registrada.


-- Registre previsao, resultado e alteracao na ficha do portal.
-- Entregue o TXT identificado e o SQL ao professor durante a aula.
